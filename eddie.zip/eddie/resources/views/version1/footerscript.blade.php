<!-- <script src="{{ asset('js/jquery.js') }}"></script> 
<script src="{{ asset('js/what-input.js') }}"></script> 
<script src="{{ asset('js/foundation.js') }}"></script> 
<script src="{{ asset('js/app.js') }}"></script> 
<script src="{{ asset('js/magnific-popup.js') }}"></script>  -->

<script src="{{ asset('js/jquery.js') }}"></script> 
<script src="{{ asset('js/what-input.js') }}"></script> 
<script src="{{ asset('js/foundation.js') }}"></script> 
<script src="{{ asset('js/magnific-popup.js') }}"></script> 
<script src="{{ asset('js/app.js') }}"></script>