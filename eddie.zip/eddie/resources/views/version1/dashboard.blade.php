
    @include('version1.headerpage')
    <h1>Dashboard</h1>
    <div class="dashboard">
      <div class="grid-x grid-padding-x align-middle">
        <div class="cell small-6 medium-3">
          <a href="/awaitingorders">
          <div class="box awaiting">Awaiting my approval<span class="notifier blue-g">{{$response['fs_P5543POA_W5543POAE']['data']['txtAwaitingA_28']['value']}}</span> </div> </a>
        </div>
        <div class="cell small-6 medium-3">
          <a href="/approvedorders">
          <div class="box approved">Approved <span class="notifier green-g">{{$response['fs_P5543POA_W5543POAE']['data']['txtApprovedC_30']['value']}}</span> </div></a>
        </div>
        <div class="cell small-6 medium-3">
          <a href="/rejectedgorders">
          <div class="box rejected">Rejected <span class="notifier red-g">{{$response['fs_P5543POA_W5543POAE']['data']['txtRejectedC_31']['value']}}</span> </div></a>
        </div>
        <div class="cell small-6 medium-3">
          <a href="/delegatedorders">
          <div class="box delegated">Delegated <span class="notifier yellow-g">{{$response['fs_P5543POA_W5543POAE']['data']['txtDelegatedC_32']['value']}}</span> </div></a>
        </div>
      </div>
      
    </div>
  </div>
</div>


  <!-- <object data="test_copy.pdf" type="application/pdf" width="100%" height="100%"> -->

  <!--    <a  href="/test_copy.pdf" target="_blank">...view Myfile..</a>


<embed src="/test_copy.pdf" type="application/pdf" width="100%" height="800px" /> -->




@include('version1.footerscript')


<script>
 
  function myFunction1(id) {
 //var orderNo=document.getElementById("OrderNo").innerHTML;
  console.log(id);
  console.log("testhhh");
   $.ajax({
           url: "get_approval_path",
           type: "GET",
           data: {
            value: id,
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           $.each(data, function(val, text) {
                           var header='<li><a class="ajax-popup-link" href="#"><img src="images/thumb.jpg" alt=""/> <div class="liHolder">';
                            var main=text['z_DL01_24']['value'];
                            var span='<span>'+text['z_DL01_26']['value'];
                            var footer='</span></div> </a></li>';

                            console.log(text['z_DL01_26']['value']);
                            console.log(text['z_RPER_23']['value']);
                           _select=_select+header+main+span+footer;

                            
                          });
                           $('#'+id).html(_select); console.log(_select);

                        }
                            
                  });
}


//document.getElementById("DelegateList").onclick = function() {myFunction(12311)};
  function myFunction(id) {
//var orderNo=document.getElementById("OrderNo").innerHTML;
  console.log(id);
  console.log("testhhh");
  var finalid=id+'OP';
   $.ajax({
           url: "get_delegation_list",
           type: "GET",
           data: {
            value: id,
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           $.each(data, function(val, text) {
                            //z_DELTOID_26
                           var header='<li onclick="selectDelegate('+id+','+text['z_DELTOID_26']['value']+')" id="test" ><a class="ajax-popup-link" href="#"><img src="images/thumb.jpg" alt=""/><div class="liHolder">';
                            var main=text['z_DL01_27']['value'];
                            //var span='<span>'+text['z_DL01_26']['value'];
                            var footer='</span></div> </a></li>';

                          
                           _select=_select+header+main+footer;

                            
                          });
                           $('#'+finalid).html(_select); console.log(_select);

                        }
                            
                  });
}

//document.getElementById("test").onclick = function() {myFunction1212(12311)};
function selectDelegate(id,addressno)
{
 $.ajax({
           url: "selectDelegate",
           type: "POST",
           data: {
            value: id,addressno: addressno, _token: '{{csrf_token()}}'
           
                                  
                  },
                    success: function(data) {
                      console.log(data);
                     //window.location.href = '/dashboard';
                           
                            
                  }
    }); 
}

function rejectbtn(id) {
  $.ajax({
           url: "rejectOrder",
           type: "POST",
           data: {
            value: id, _token: '{{csrf_token()}}'
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           
                            
                  }
    });

  }

  function Approvebtn(id) {
  $.ajax({
           url: "approveOrder",
           type: "POST",
           data: {
            value: id, _token: '{{csrf_token()}}'
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           
                            
                  }
    });

  }
  
  

</script>
</body>
</html>
