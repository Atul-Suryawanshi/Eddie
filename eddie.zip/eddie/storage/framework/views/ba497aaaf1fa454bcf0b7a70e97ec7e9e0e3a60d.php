<!doctype html>
<html class="no-js" lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edwards Lifesciences – the leader in heart valves &amp; hemodynamic monitoring | Edwards Lifesciences</title>
	  <link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/foundation.css">
    <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" href="css/media-queries.css">
  </head>
  <body>
   <div class="wrapper login-bg">
	  <div class="login-wrapper">
	   <div class="logo-holder"><img src="images/logo.svg" alt="Edwards Lifesciences" title="Edwards Lifesciences"></div>
		  
		  <form method="post" action="dashboard" >
    <?php echo csrf_field(); ?>

    

       
        

  
  <div class="field">
    <input type="email" name="username" id="username" placeholder="abc@domain.com">
    <label for="username">Username</label>
  </div>
			  
			    <div class="field noBottomMrgn">
    <input type="password" name="password" id="password" placeholder="**********">
    <label for="password">password</label>
					

					
  </div>
			  
			 <!--  <div class="field"><a href="javascript:void(0);" class="helper-txt">Forgot password?</a></div> -->
			  
			 <div class="field"><input type="submit" class="std-btn"></div>
		  
		  </form>
		  
     </div>
	  </div>
    

    <script src="js/vendor/jquery.js"></script>
s    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.js"></script>
    <script src="js/app.js"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\eddie\resources\views/version1/index.blade.php ENDPATH**/ ?>