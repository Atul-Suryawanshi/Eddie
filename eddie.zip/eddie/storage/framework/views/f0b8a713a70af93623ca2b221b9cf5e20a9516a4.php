     <?php echo $__env->make('version1.headerpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h3 class="details-title"><?php echo e($orderHeader['z_ALPH_41']['value']); ?> <span>#<?php echo e($orderHeader['z_DOCO_17']['value']); ?>-<?php echo e($orderHeader['z_DCTO_19']['value']); ?>-<?php echo e($orderHeader['z_KCOO_21']['value']); ?></span></h3>
    <div class="dashboard">
      <div class="dataTable">
        <div class="grid-x grid-padding-x">
          <div class="cell small-12">
            <div class="detailsContainer">
              <div class="grid-x grid-padding-x grid-margin-x">
               <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cell small-12 medium-4">
                  <div class="detailsBox">
                    <div class="detailsSubtitle"><?php echo e($value['z_DSC1_29']['value']); ?></div>
                    <div class="details cf"> <span class="left">Total</span><span class="right"><?php echo e($value['z_AEXP_32']['value']); ?></span> </div>
                    <div class="details cf"> <span class="left">Unit Price</span><span class="right"><?php echo e($value['z_PRRC_40']['value']); ?></span> </div>
                    <div class="details cf"> <span class="left">Order Quantity</span><span class="right"><?php echo e($value['z_UORG_30']['value']); ?></span></div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	  
	  <div class="footerContainer">
	  <div class="grid-x grid-padding-x align-right"> <!-- Aligned to the center -->
  <div class="cell small-12">
		  
		  <div class="action-container">
                      <ul>
                        <?php if($calledfrom==15): ?>
                         <!--  <li><a class="apath2" onclick = "myFunction(<?php //echo $orderHeader['z_DOCO_17']['value']; ?>)" href="javascript:void(0);"><span class="icon-icons"></span>Delegate</a>
                          <div class="dd2">
                            
                            <ul id=<?php //echo $orderHeader['z_DOCO_17']['value'].$orderHeader['z_DCTO_19']['value']; ?>>
                             
                            </ul>
                            
                          </div>
                           </li>
 -->

                           <li><a class="apath2"  onclick = "DelegateList(<?php echo  $orderHeader['z_DOCO_17']['value']; ?>)"  href="javascript:void(0);"><span class="icon-icons"></span>Delegate</a>
                          <div class="dd2">
                            <ul id=<?php echo $orderHeader['z_DOCO_17']['value'].$orderHeader['z_DCTO_19']['value']; ?>>

                              
                            </ul>
                          </div>
                         </li>


                          <?php endif; ?>
                        <li><a class="img-popup" href="images/popoup.jpg"><span class="icon-attachment"></span> Attachment</a></li>
                        <?php if($calledfrom==15): ?>
                        <li><a class="ajax-popup-link"  onclick = "Approvebtn(<?php echo $orderHeader['z_DOCO_17']['value']; ?>)" href="comments.html"><span class="icon-tick"></span> Approve</a></li>
                        <li><a class="ajax-popup-link" onclick = "rejectbtn(<?php echo $orderHeader['z_DOCO_17']['value']; ?>)" href="reject.html"><span class="icon-reject"></span> Reject</a></li>
                        <?php endif; ?>
                      </ul>
                    </div>
		  
		  </div>
		  
		  
		  <div class="cell small-12">
		  <div class="footerTabs">
			  <ul>
			  	<li><a href="#">Order</a></li>
			  	<li class="active"><a href="#">Order Details</a></li>
			  	<li><a href="#">Order Notes</a></li>
			  </ul>
			  </div>
		  
		  </div>
 
</div>
	  
	  </div>
	  
	  
  </div>
</div>

<?php echo $__env->make('version1.footerscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
 //$(document).ready(function(){
  //code for approva path
 // document.getElementById("ApprovalPathBtn1").onclick = function() {myFunction1(20158498)};
  function myFunction1(id) {
 //var orderNo=document.getElementById("OrderNo").innerHTML;
  console.log(id);
  console.log("testhhh");
   $.ajax({
           url: "get_approval_path",
           type: "GET",
           data: {
            value: id,
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           $.each(data, function(val, text) {
                           var header='<li><a class="ajax-popup-link" href="#"><img src="images/thumb.jpg" alt=""/> <div class="liHolder">';
                            var main=text['z_DL01_24']['value'];
                            var span='<span>'+text['z_DL01_26']['value'];
                            var footer='</span></div> </a></li>';

                            console.log(text['z_DL01_26']['value']);
                            console.log(text['z_RPER_23']['value']);
                           _select=_select+header+main+span+footer;

                            
                          });
                           $('#'+id).html(_select); console.log(_select);

                        }
                            
                  });
}


//document.getElementById("DelegateList").onclick = function() {myFunction(12311)};
  function DelegateList(id) {
//var orderNo=document.getElementById("OrderNo").innerHTML;
  console.log(id);
  console.log("testhhh");
  var finalid=id+'OP';
   $.ajax({
           url: "/get_delegation_list",
           type: "GET",
           data: {
            value: id,
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           var image_src="<?php echo e(asset('images/thumb.jpg')); ?>";
                           $.each(data, function(val, text) {
                            //z_DELTOID_26
                           var header='<li onclick="selectDelegate('+id+','+text['z_DELTOID_26']['value']+')" id="test" ><a class="ajax-popup-link" href="#"><img src="'+image_src+'" alt=""/><div class="liHolder">';
                            var main=text['z_DL01_27']['value'];
                            //var span='<span>'+text['z_DL01_26']['value'];
                            var footer='</span></div> </a></li>';

                          
                           _select=_select+header+main+footer;

                            
                          });
                           $('#'+finalid).html(_select); console.log(_select);

                        }
                            
                  });
}

//document.getElementById("test").onclick = function() {myFunction1212(12311)};
function selectDelegate(id,addressno)
{
 $.ajax({
           url: "selectDelegate",
           type: "POST",
           data: {
            value: id,addressno: addressno, _token: '<?php echo e(csrf_token()); ?>'
           
                                  
                  },
                    success: function(data) {
                      console.log(data);
                     //window.location.href = '/dashboard';
                           
                            
                  }
    }); 
}

function rejectbtn(id) {
  $.ajax({
           url: "/rejectOrder",
           type: "POST",
           data: {
            value: id, _token: '<?php echo e(csrf_token()); ?>'
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           
                            
                  }
    });

  }

  function Approvebtn(id) {
  $.ajax({
           url: "/approveOrder",
           type: "POST",
           data: {
            value: id, _token: '<?php echo e(csrf_token()); ?>'
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           
                            
                  }
    });

  }
  
   
console.log("TEST");  
// });  
</script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\eddie\resources\views/version1/order_details.blade.php ENDPATH**/ ?>