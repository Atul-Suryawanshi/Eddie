<!-- <script src="js/jquery.js"></script> 
<script src="js/what-input.js"></script> 
<script src="js/foundation.js"></script> 
<script src="js/magnific-popup.js"></script> 
<script src="js/app.js"></script>  -->

<script src="<?php echo e(asset('js/jquery.js')); ?>"></script> 
<script src="<?php echo e(asset('js/what-input.js')); ?>"></script> 
<script src="<?php echo e(asset('js/foundation.js')); ?>"></script> 
<script src="<?php echo e(asset('js/magnific-popup.js')); ?>"></script> 
<script src="<?php echo e(asset('js/app.js')); ?>"></script> <?php /**PATH C:\xampp\htdocs\eddie\resources\views/version1/default/footer.blade.php ENDPATH**/ ?>