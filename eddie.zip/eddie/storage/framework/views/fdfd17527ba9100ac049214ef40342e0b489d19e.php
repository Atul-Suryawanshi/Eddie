<!doctype html>
<html class="no-js" lang="en" dir="ltr">
<?php echo $__env->make('version1.default.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div class="wrapper">
  <div class="main-contents">
    <header>
      <div class="grid-x grid-padding-x align-middle">
        <div class="cell small-4">
          <div class="account-box"><a href="javascript:void(0);"><span class="icon-account"></span><span class="icon-txt">My Account</span></a></div>
        </div>
        <div class="cell small-4">
          <div class="logo"><a href="/dashboard"><img src="images/logo-straight.svg" alt="Edwards Lifesciences" title="Edwards Lifesciences"></a></div>
        </div>
        <div class="cell small-4">
          <div class="right-menu">
            <ul>
              <li><a href="javascript:void(0);"><span class="icon-menu"></span></a></li>
              <li><a href="javascript:void(0);"><span class="icon-notification"></span></a></li>
            </ul>
          </div>
        </div>
      </div>
    </header>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('version1.default.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\eddie\resources\views/version1/default/main.blade.php ENDPATH**/ ?>