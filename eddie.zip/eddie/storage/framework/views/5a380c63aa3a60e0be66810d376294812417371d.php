<!doctype html>
<html class="no-js" lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Details | Edwards Lifesciences</title>
<link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans:wght@300;400;600&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('css/foundation.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/media-queries.css')); ?>">
</head>
<body>
<div class="wrapper">
  <div class="main-contents">
    <header>
      <div class="grid-x grid-padding-x align-middle">
        <div class="cell small-4">
          <div class="account-box"><a href="#"><span class="icon-account"></span><span class="icon-txt">My Account</span></a></div>
        </div>
        <div class="cell small-4">
          <div class="logo"><a href="/dashboard"><img src="<?php echo e(asset('images/logo-straight.svg')); ?>" alt="Edwards Lifesciences" title="Edwards Lifesciences"></a></div>
        </div>
        <div class="cell small-4">
          <div class="right-menu">
            <ul>
              <li><a href="#"><span class="icon-menu"></span></a></li>
              <li><a href="#"><span class="icon-notification"></span></a></li>
            </ul>
          </div>
        </div>
      </div>
    </header><?php /**PATH C:\xampp\htdocs\eddie\resources\views/version1/headerpage.blade.php ENDPATH**/ ?>