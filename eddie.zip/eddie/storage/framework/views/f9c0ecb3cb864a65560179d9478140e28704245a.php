<!doctype html>
<html class="no-js" lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Approver | Edwards Lifesciences</title>
<link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans:wght@300;400;600&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('css/foundation.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/media-queries.css')); ?>">
</head>
<body>
<div class="wrapper">
  <div class="main-contents">
    <header>
      <div class="grid-x grid-padding-x align-middle">
        <div class="cell small-4">
          <div class="account-box"><a href="#"><span class="icon-account"></span><span class="icon-txt">My Account</span></a></div>
        </div>
        <div class="cell small-4">
          <div class="logo"><a href="/dashboard"><img src="images/logo-straight.svg" alt="Edwards Lifesciences" title="Edwards Lifesciences"></a></div>
        </div>
        <div class="cell small-4">
          <div class="right-menu">
            <ul>
              <li><a href="#"><span class="icon-menu"></span></a></li>
              <li><a href="#"><span class="icon-notification"></span></a></li>
            </ul>
          </div>
        </div>
      </div>
    </header>
   
    <h1><?php echo e($formName); ?></h1>
    <div class="dashboard">
      
      <div class="dataTable">
        <div class="grid-x grid-padding-x">
          <?php $__currentLoopData = $orderdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="cell small-12 medium-6">
            <div class="dataBox">
              <div class="grid-x grid-padding-x">
                <div class="cell small-6 medium-9">
                  <div class="name"><?php echo e($data['z_DL01_60']['value']); ?> </div>
                  <div class="description">
                    <p>$<?php echo e($data['z_OTOT_42']['value']); ?></p>
                    <p><?php echo e($data['z_DOCO_34']['value']); ?>-<?php echo e($data['z_DCTO_35']['value']); ?>-<?php echo e($data['z_KCOO_36']['value']); ?></p>
                    <p><?php echo e($data['z_DRQJ_43']['value']); ?></p>
                    <p id ="OrderNo" hidden><?php echo e($data['z_DOCO_34']['value']); ?></p>
                  </div>
                </div>
                <div class="cell small-6 medium-3">
                  <div class="action-box">
                    <?php if($calledfrom==15): ?>
                    <div class="days">Days Order Created <?php echo e($data['z_DSC1_79']['value']); ?></div>
                    <div class="days">Days Last Approve <?php echo e($data['z_DSC1_80']['value']); ?></div>
                    <?php endif; ?>
                    <div class="details-box"><a href="/order_details/<?php echo e($data['z_DOCO_34']['value']); ?>/<?php echo e($calledfrom); ?>"><span class="icon-details"></span> Details</a></div>
                    <a class="arrow-holder" href="#"><span class="reveal1 icon-down-arrow"></span></a> </div>
                </div>
                <?php if($calledfrom==15): ?>
                <div class="cell small-6 medium-12">
                   <div class="approver">Last Approver: <span><?php echo e($data['z_DL01_61']['value']); ?></span></div>
                  <div class="approver">Notes: <span><?php echo e($data['z_98NOTES_55']['value']); ?></span></div>
                </div>
                <?php endif; ?>
              </div>
              <div class="action-box2">
                <div class="grid-x">
                  <div class="cell small-4">
                     <div class="apath clearfix" onclick = "myFunction1(<?php echo $data['z_DOCO_34']['value']; ?>)" id="ApprovalPathBtn1"><a href="javascript:void(0);">Approval Path<span class="reveal2 icon-down-arrow" ></span></a>
                      
                      <div class="dd1">
                        <ul id=<?php echo $data['z_DOCO_34']['value'];?> >
                          
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="cell small-8">
                    <div class="action-container">
                      <ul>
                        <?php if($calledfrom==15): ?>
                         <li><a class="apath2"  onclick = "DelegateList(<?php echo $data['z_DOCO_34']['value']; ?>)"  href="javascript:void(0);"><span class="icon-icons"></span>Delegate</a>
                          <div class="dd2">
                            <ul id=<?php echo $data['z_DOCO_34']['value'].'OPTest'; ?>>
                              <li><a class="ajax-popup-link" href="comments.html"><img src="images/thumb.jpg" alt=""/>
                            <div class="liHolder">Robert Warren <span>0214</span></div>
                            </a></li>
                          <li><a class="ajax-popup-link" href="comments.html"><img src="images/thumb.jpg" alt=""/>
                            <div class="liHolder">Robert Warren <span>0214</span></div>
                            </a></li>
                          <li><a class="ajax-popup-link" href="comments.html"><img src="images/thumb.jpg" alt=""/>
                            <div class="liHolder">Robert Warren <span>0214</span></div>
                            </a></li>
                              
                            </ul>
                          </div>
                         </li>
                        <?php endif; ?>
                       
                        <li><a href="#"><span class="icon-attachment"></span> Attachment</a></li>
                        <?php if($calledfrom==15): ?>
                        <li><a class="ajax-popup-link"  onclick = "Approvebtn(<?php echo $data['z_DOCO_34']['value']; ?>)" href="comments.html"><span class="icon-tick"></span> Approve</a></li>
                        <li><a class="ajax-popup-link" onclick = "rejectbtn(<?php echo $data['z_DOCO_34']['value']; ?>)" href="reject.html"><span class="icon-reject"></span> Reject</a></li>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<!-- 
			<div class="cell small-12 medium-6">
            <div class="dataBox">
              <div class="grid-x grid-padding-x">
                <div class="cell small-6 medium-9">
                  <div class="name">Michael Smith </div>
                  <div class="description">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam justo velit, condimentum congue orci non, condimentum elementum leo. Integer feugiat rutrum dolor, non maximus nunc varius vel.</p>
                  </div>
                </div>
                <div class="cell small-6 medium-3">
                  <div class="action-box">
                    <div class="days">-2 Days </div>
                    <div class="details-box"><a href="#"><span class="icon-details"></span> Details</a></div>
                    <a class="arrow-holder" href="#"><span class="reveal1 icon-down-arrow"></span></a> </div>
                </div>
                <div class="cell small-6 medium-12">
                  <div class="approver">Last Approver: <span>John Smith</span></div>
                </div>
              </div>
              <div class="action-box2">
                <div class="grid-x">
                  <div class="cell small-4">
                    <div class="apath"><a href="#">Approval Path<span class="reveal2 icon-down-arrow"></span></a>
                      <div class="dd1">
                        <ul>
                          <li><img src="images/thumb.jpg" alt=""/>Robert Warren <span>0214</span> </li>
                          <li><img src="images/thumb.jpg" alt=""/>Robert Warren <span>0214</span> </li>
                          <li><img src="images/thumb.jpg" alt=""/>Robert Warren <span>0214</span> </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="cell small-8">
                    <div class="action-container">
                      <ul>
                        <li><a href="#"><span class="icon-icons"></span> Delegate</a></li>
                        <li><a href="#"><span class="icon-attachment"></span> Attachment</a></li>
                        <li><a href="#"><span class="icon-tick"></span> Approve</a></li>
                        <li><a href="#"><span class="icon-reject"></span> Reject</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
			<div class="cell small-12 medium-6">
            <div class="dataBox">
              <div class="grid-x grid-padding-x">
                <div class="cell small-6 medium-9">
                  <div class="name">Michael Smith </div>
                  <div class="description">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam justo velit, condimentum congue orci non, condimentum elementum leo. Integer feugiat rutrum dolor, non maximus nunc varius vel.</p>
                  </div>
                </div>
                <div class="cell small-6 medium-3">
                  <div class="action-box">
                    <div class="days">-2 Days </div>
                    <div class="details-box"><a href="#"><span class="icon-details"></span> Details</a></div>
                    <a class="arrow-holder" href="#"><span class="reveal1 icon-down-arrow"></span></a> </div>
                </div>
                <div class="cell small-6 medium-12">
                  <div class="approver">Last Approver: <span>John Smith</span></div>
                </div>
              </div>
              <div class="action-box2">
                <div class="grid-x">
                  <div class="cell small-4">
                    <div class="apath"><a href="#">Approval Path<span class="reveal2 icon-down-arrow"></span></a>
                      <div class="dd1">
                        <ul>
                          <li><img src="images/thumb.jpg" alt=""/>Robert Warren <span>0214</span> </li>
                          <li><img src="images/thumb.jpg" alt=""/>Robert Warren <span>0214</span> </li>
                          <li><img src="images/thumb.jpg" alt=""/>Robert Warren <span>0214</span> </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="cell small-8">
                    <div class="action-container">
                      <ul>
                        <li><a href="#"><span class="icon-icons"></span> Delegate</a></li>
                        <li><a href="#"><span class="icon-attachment"></span> Attachment</a></li>
                        <li><a href="#"><span class="icon-tick"></span> Approve</a></li>
                        <li><a href="#"><span class="icon-reject"></span> Reject</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
           -->
          
        </div>
      </div>
    </div>
  </div>
</div>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script> 
<script src="<?php echo e(asset('js/what-input.js')); ?>"></script> 
<script src="<?php echo e(asset('js/foundation.js')); ?>"></script> 
<script src="<?php echo e(asset('js/app.js')); ?>"></script> 

<script>
    $(".arrow-holder").click(function() {
		$(".action-box2").slideToggle();
		$(this).find(".reveal1").toggleClass("icon-top-arrow icon-down-arrow");
        // assumes element with id='button'
//        $(".action-box2").slideToggle();
//        $(".reveal1").toggleClass("icon-top-arrow icon-down-arrow");
    });
		
		$(".apath").click(function() {
			
			$(this).find(".dd1").slideToggle();
			$(this).find(".reveal2").toggleClass("icon-top-arrow icon-down-arrow");

    });
		
		
</script>

<script>
  function myFunction1(id) {

  var calledfrom=<?php echo e($calledfrom); ?>;
   if (calledfrom==15)
   {
   var url_link="get_approval_path";
    }
    else
    {
      var url_link="get_approval_path_NonAwaiting";
    }
  console.log(calledfrom);
   $.ajax({
           url: url_link,
           type: "GET",
           data: {
            value: id,calledfrom: calledfrom,
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           $.each(data, function(val, text) {
                           var header='<li><a class="ajax-popup-link" href="#"><img src="images/thumb.jpg" alt=""/> <div class="liHolder">';
                            var main=text['z_DL01_24']['value'];
                            var span='<span>'+text['z_DL01_26']['value'];
                            var footer='</span></div> </a></li>';

                            console.log(text['z_DL01_26']['value']);
                            console.log(text['z_RPER_23']['value']);
                           _select=_select+header+main+span+footer;

                            
                          });
                           $('#'+id).html(_select); console.log(_select);

                        }
                            
                  });
}


//document.getElementById("DelegateList").onclick = function() {myFunction(12311)};
  function DelegateList(id) {
//var orderNo=document.getElementById("OrderNo").innerHTML;
  console.log(id);
  console.log("In side Delegate");
  var finalid=id+'OPTest';
  console.log(finalid);
   $.ajax({
           url: "/get_delegation_list",
           type: "GET",
           data: {
            value: id,
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           var image_src="<?php echo e(asset('images/thumb.jpg')); ?>";
                           $.each(data, function(val, text) {
                            //z_DELTOID_26
                           var header='<li onclick="selectDelegate('+id+','+text['z_DELTOID_26']['value']+')" id="test" ><a class="ajax-popup-link" href="#"><img src="'+image_src+'" alt=""/><div class="liHolder">';
                            var main=text['z_DL01_27']['value'];
                            //var span='<span>'+text['z_DL01_26']['value'];
                            var footer='</span></div> </a></li>';

                          
                           _select=_select+header+main+footer;

                            
                          });
                          // $('#'+finalid).html(_select); 
                           console.log(_select);

                        }
                            
                  });
}

//document.getElementById("test").onclick = function() {myFunction1212(12311)};
function selectDelegate(id,addressno)
{
 $.ajax({
           url: "selectDelegate",
           type: "POST",
           data: {
            value: id,addressno: addressno, _token: '<?php echo e(csrf_token()); ?>'
           
                                  
                  },
                    success: function(data) {
                      console.log(data);
                     //window.location.href = '/dashboard';
                           
                            
                  }
    }); 
}

function rejectbtn(id) {
  $.ajax({
           url: "/rejectOrder",
           type: "POST",
           data: {
            value: id, _token: '<?php echo e(csrf_token()); ?>'
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           
                            
                  }
    });

  }

  function Approvebtn(id) {
  $.ajax({
           url: "/approveOrder",
           type: "POST",
           data: {
            value: id, _token: '<?php echo e(csrf_token()); ?>'
           
                                  
                  },
                    success: function(data) {
                      var _select ='';
                           console.log(data);
                           
                            
                  }
    });

  }
  
   

</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\eddie\resources\views/version1/orders.blade.php ENDPATH**/ ?>