<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DemoController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\CallAPIController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('version1.index');
});

Route::post('dashboard',[DemoController::class,'get_dashboard']);
//to redirect dashboard
Route::get('dashboard',[DemoController::class,'get_dashboard']);

Route::get('get_token',[DemoController::class,'get_token']);

Route::get('get_approval_path',[PhotoController::class,'get_approval_path']);
Route::get('get_approval_path_NonAwaiting',[CallAPIController::class,'get_approval_path_NonAwaiting']);
Route::get('get_delegation_list',[PhotoController::class,'get_delegation_list']);

Route::get('order_details/{url}/{url1}',[CallAPIController::class,'order_details']);

Route::get('awaitingorders',[CallAPIController::class,'getawaitingorders']);
Route::get('approvedorders',[CallAPIController::class,'getapprovedorders']);
Route::get('rejectedgorders',[CallAPIController::class,'getrejectedorders']);
Route::get('delegatedorders',[CallAPIController::class,'getdelegatedorders']);

Route::post('approveOrder',[CallAPIController::class,'approveOrder']);

Route::post('rejectOrder',[CallAPIController::class,'rejectOrder']);

Route::post('selectDelegate',[CallAPIController::class,'selectDelegate']);


Route::get('copyImage',[DemoController::class,'copyImage']);