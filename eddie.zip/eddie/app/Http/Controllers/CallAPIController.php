<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\DemoController;
use App\Http\Controllers\PhotoController;
class CallAPIController extends Controller
{
    //
    public function order_details($order_no,$calledfrom)
    {
    	$DemoController=new DemoController();
    	$test=$DemoController->getAllOrders($calledfrom);

        $PhotoController=new PhotoController();
        $response=$PhotoController->getAwaitingApprovalOrderDetails($order_no);
 		$data= $response['fs_P5543POA_W5543POAF']['data']['gridData']['rowset'];
        $orderHeader= $response['fs_P5543POA_W5543POAF']['data'];
        $PhotoController->closeAwaitingorderDetailForm();

        $DemoControllers=new DemoController();
        $DemoControllers->closeAawaitingApprovalForm();
        
       
    	return view('version1.order_details')->with('order_details',$data)->with('orderHeader',$orderHeader)->with('calledfrom',$calledfrom);
    }
    public function getawaitingorders()
    {
    	$calledfrom=15;
    	$formName="Awaiting Approval Purchase Orders";
    	$DemoController=new DemoController();
    	$data=$DemoController->getAllOrders($calledfrom);

    	$DemoControllers=new DemoController();
        $DemoControllers->closeAawaitingApprovalForm();
    	//return $data;
    	return view('version1.orders')->with('orderdata',$data)->with('calledfrom',$calledfrom)->with('formName',$formName);
    }
    public function getapprovedorders()
    {
    	$calledfrom=16;
    	$formName="Approved Purchase Orders";
    	$DemoController=new DemoController();
    	$data=$DemoController->getAllOrders($calledfrom);

    	$DemoControllers=new DemoController();
        $DemoControllers->closeAawaitingApprovalForm(); 
    	
    	return view('version1.orders')->with('orderdata',$data)->with('calledfrom',$calledfrom)->with('formName',$formName);
    }
    public function getrejectedorders()
    {
    	$calledfrom=17;
    	$formName=" Rejected Purchase Orders";
    	$DemoController=new DemoController();
    	$data=$DemoController->getAllOrders($calledfrom);

    	$DemoControllers=new DemoController();
        $DemoControllers->closeAawaitingApprovalForm();
    	
    	return view('version1.orders')->with('orderdata',$data)->with('calledfrom',$calledfrom)->with('formName',$formName);
    }
    public function getdelegatedorders()
    {
    	$calledfrom=18;
    	$formName="Delegated Purchase Orders";
    	$DemoController=new DemoController();
    	$data=$DemoController->getAllOrders($calledfrom);

    	$DemoControllers=new DemoController();
        $DemoControllers->closeAawaitingApprovalForm();
    	
    	return view('version1.orders')->with('orderdata',$data)->with('calledfrom',$calledfrom)->with('formName',$formName);
    }

    public function rejectOrder(Request $request)
    {
    	$DemoController=new DemoController();
    	$test=$DemoController->getAllOrders(15);
    	$request['reason']="Order Rejected";
    	$request['controlId']=55;
    	$PhotoController=new PhotoController();
    	$PhotoController->openAwaitingForm($request);
    	$PhotoController->setRejectionReasonAndRejectOrder($request);
    	return $request;
    }
    public function approveOrder(Request $request)
    {
    	$DemoController=new DemoController();
    	$test=$DemoController->getAllOrders(15);
    	$request['reason']="Order Approved";
    	$request['controlId']=54;
    	$PhotoController=new PhotoController();
    	$PhotoController->openAwaitingForm($request);
    	$PhotoController->setRejectionReasonAndRejectOrder($request);
    	return $request;
    }

    public function selectDelegate(Request $request)
    {
    	$DemoController=new DemoController();
    	$test=$DemoController->getAllOrders(15);
    	$request['reason']=02;
    	$PhotoController=new PhotoController();
    	$PhotoController->openAwaitingForm($request);
    	$PhotoController->getDelegator($request);
    	//set delegaton reason and delegator
    return 	$PhotoController->setDelegator($request);
    	return 'Success';

    }

    public function get_approval_path_NonAwaiting(Request $request)
    {
    	//return $request;
    	$calledfrom=18;
    	$DemoController=new DemoController();
    	$data=$DemoController->getAllOrders($calledfrom);
    	$PhotoController=new PhotoController();
    	$data=$PhotoController->openNonAwaitingForm($request);
    	$PhotoController->closeNonAwaitingForm();
    	$DemoControllers=new DemoController();
        $DemoControllers->closeAawaitingApprovalForm();
    	return $data;
    	

    }


}
