<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use File;

class DemoController extends Controller
{
    //
  public function order_details($url)
    {
      return view('version1.order_details');
    }


    public function get_dashboard(Request $request)
    {

/*echo  session()->get('stackId');
echo "<br>";
echo  session()->get('stateId');
echo "<br>";
echo  session()->get('rid');
echo "<br>";


return  session()->get('token');*/
  	$token=$this->get_token();
    //return $token;
    session()->put('token',$token);
    $curl = curl_init();
    
    $no_url=urlencode("109675");
    $request1='{
    "token":"';
    $request2=$token;
    $request3='",
    "deviceName": "Postman",
    "formName": "P5543POA_W5543POAE",
    
    "action": "open",
    "outputType": "VERSION2",
    "formRequest": {
        "maxPageSize": "5",
      
        "formActions": [
          {
      "controlID": "20",
      "value": "109675",
      "command": "SetControlValue"
    }
           
           
        ],
        "formName": "P5543POA_W5543POAE",
        "version": "POS0001",
        "formServiceAction": "A",
        "bypassFormServiceEREvent": false
    },
    "stackId": 0,
    "stateId": 0
}';
  $request= $request1.$request2.$request3;
 
  $curl = curl_init();

  curl_setopt_array($curl, array(
  CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>$request,
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json"
  ),
));

$result = curl_exec($curl);
$err=curl_error($curl);
if($err){
echo $err;
}
curl_close($curl);
//echo $result;
 $response=json_decode($result,true);

$stackId=$response['stackId'];
$stateId=$response['stateId'];
$rid=$response['rid'];
session()->put('stackId',$response['stackId']);
session()->put('stateId',$response['stateId']);
session()->put('rid',$response['rid']);

$awaitingdata= $this->get_awaitingdata();
//echo session()->get('token');
//return $awaitingdata;
$this->closeAawaitingApprovalForm();

 return view('version1.dashboard')->with('response',$response)->with('awaitingdata',$awaitingdata);

    }

	

  public function get_token()
  {


$curl = curl_init();
$request='{
	"deviceName":"Postman",
	"username":"sshetty",
	"password":"Shivaji92"
}
';
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/tokenrequest",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>$request,
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json",
    "Cookie: JSESSIONID=BlNRRkA7Phg2M-EYiH2blBYN3PSJO2ugLz8Wr1MmFabKm7tnZPI0!-643701928"
  ),
));

$result = curl_exec($curl);

curl_close($curl);
//echo $response;
$response=json_decode($result,true);
$token=$response['userInfo']['token'];
return $token;
   }
   public function get_awaitingdata()
   {
    
    $request1='{
      "token":"';
     $request2=session()->get('token');
     $request3='",
      "deviceName": "Postman",
     
      "aliasNaming": true,
      "maxPageSize": "1",
      "action": "execute",
      "outputType": "VERSION2",
      "actionRequest": {
        
        "formActions": [

    {
      "controlID": "15",
      "command": "DoAction"
      }
      
      
        ],
        "formOID": "W5543POAE"
    },
       "stackId": ';

      $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

      $request=$request1.$request2.$request3.$request4;
      //return $request;

    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS =>$request,
      CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json"
      ),
    ));

    $result = curl_exec($curl);

    curl_close($curl);
    //echo $response;
    $response=json_decode($result,true);
    session()->put('stackId',$response['stackId']);
    session()->put('stateId',$response['stateId']);
    session()->put('rid',$response['rid']);
    $data= $response['fs_P5543POA_W5543POAC']['data']['gridData']['rowset'];
    /*foreach ($data as $value) {
      return  $value['z_DOCO_34']['value'];
     
      # code...
    }*/
    return $data;

   }

   public function closeAawaitingApprovalForm()
   {
        $request1='{
      "token":"';
     $request2=session()->get('token');
     $request3='",
      "deviceName": "Postman",
     
      "aliasNaming": true,
      "maxPageSize": "1",
      "action": "execute",
      "outputType": "VERSION2",
      "actionRequest": {
        
        "formActions": [

    {
      "controlID": "13",
      "command": "DoAction"
      }
      
      
        ],
        "formOID": "W5543POAC"
    },
       "stackId": ';

      $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

      $request=$request1.$request2.$request3.$request4;

        $curl = curl_init();
  
        curl_setopt_array($curl, array(
        CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS =>$request,
        CURLOPT_HTTPHEADER => array(
          "Content-Type: application/json"
        ),
      ));

      $result = curl_exec($curl);

      curl_close($curl);
      //echo $response;
      $response=json_decode($result,true);
      session()->put('stackId',$response['stackId']);
      session()->put('stateId',$response['stateId']);
      session()->put('rid',$response['rid']);

   }


   public function getAllOrders($calledfor)
   {
        $request1='{
          "token":"';
         $request2=session()->get('token');
         $request3='",
          "deviceName": "Postman",
         
          "aliasNaming": true,
          "maxPageSize": "100",
          "action": "execute",
          "outputType": "VERSION2",
          "actionRequest": {
            
            "formActions": [

        {
          "controlID": "';
          $controlId=$calledfor.'",
          "command": "DoAction"
          }
          
          
            ],
            "formOID": "W5543POAE"
        },
           "stackId": ';

          $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $request=$request1.$request2.$request3.$controlId.$request4;
          //return $request;

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 100,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS =>$request,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
          ),
        ));

        $result = curl_exec($curl);

        curl_close($curl);
        //echo $response;
        $response=json_decode($result,true);
        session()->put('stackId',$response['stackId']);
        session()->put('stateId',$response['stateId']);
        session()->put('rid',$response['rid']);
        $data= $response['fs_P5543POA_W5543POAC']['data']['gridData']['rowset'];
        /*foreach ($data as $value) {
          return  $value['z_DOCO_34']['value'];
         
          # code...
        }*/
       // $this->closeAawaitingApprovalForm();
        return $data;

   }

    public function copyImage(Request $request)
    {
        File::copy('//awpjdefs01/mediaobj/HTMLUpload/FILE-1109202022008.pdf', public_path('test/test_copy.pdf'));
   
        dd('Copy File dont.');




    }

	
}
