<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\DemoController;
class PhotoController extends Controller
{
    public function get_approval_path(Request $request)
    {  
         $DemoController=new DemoController();
         $DemoController-> get_awaitingdata();
          $this->openAwaitingForm($request);
          $getappoval= $this->getappoval();
         $this->closeapprovalpath();
         $this->closeApprove_rejectForm();
         return $getappoval;
            }


        public function getappoval()
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "controlID": "71",
                 "command": "DoAction"
              }
                
            ],
            "formOID": "W5543POAA"
        },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
            $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Cookie: JSESSIONID=BlNRRkA7Phg2M-EYiH2blBYN3PSJO2ugLz8Wr1MmFabKm7tnZPI0!-643701928"
              ),
            ));

            $result = curl_exec($curl);
            $err=curl_error($curl);


             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);
             $data= $response['fs_P5543POA_W5543POAD']['data']['gridData']['rowset'];
             return $data;
        }
        public function closeapprovalpath()
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "controlID": "13",
                 "command": "DoAction"
              }
                
            ],
            "formOID": "W5543POAD"
        },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
            $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Cookie: JSESSIONID=BlNRRkA7Phg2M-EYiH2blBYN3PSJO2ugLz8Wr1MmFabKm7tnZPI0!-643701928"
              ),
            ));

            
            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);
        }

        public function get_delegation_list(Request $request)
        {  
            $DemoController=new DemoController();
            $DemoController->get_awaitingdata();

            $this->openAwaitingForm($request);
            $data=$this->getDelegator($request);
           
             $this->closeDelegationForm();
             $this->closeApprove_rejectForm();
             return $data;

        }
        public function getDelegator($request)
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "controlID": "119",
                 "command": "DoAction"
              }
                
            ],
            "formOID": "W5543POAA"
        },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
              $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);
             return  $response['fs_P5543POA_W5543POAB']['data']['gridData']['rowset'];
        }
        public function setDelegator($request)
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               
               {
                "command": "SetQBEValue",
                 "controlID": "1[26]",
                   "value": "'.$request['addressno'].'"
            },
               {
                "controlID": "23",
                 "command": "DoAction"

              },
              {
                "gridAction": 
                {
                "gridID": "1",
                    "gridRowUpdateEvents": [
                        {
                            "rowNumber": 1,
                            "gridColumnEvents": [
                                {
                                    "value": "'.$request['reason'].'",
                                    "command": "SetGridCellValue",
                                    "columnID": "41"
                
                                }
                                
                            ]
                        }
                    ]
                }
            }
            ,{
                    
                "command": "DoAction",
                "controlID": "28"
                
            }
                
                
            ],
            "formOID": "W5543POAB"
        },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
          //return $requestdata;
              $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);
        }

        public function closeDelegationForm()
        {
              $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "controlID": "13",
                 "command": "DoAction"
              }
                
            ],
            "formOID": "W5543POAB"
             },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
              $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);

        }

        public function  openAwaitingForm(Request $request)
        {
            $request1='{
        "token": "';
        $request2=session()->get('token');
        $request3='","deviceName": "Postman",
       
        "aliasNaming": true,    
        "allowCache": true,
        "maxPageSize": "100",
        "action": "execute",
        "outputType": "VERSION2",
        "actionRequest": {
        
        "formActions": [
        
           {
            "command": "SetQBEValue",
             "controlID": "1[34]",
               "value": "';
        $request4= $request['value'];
        $request5='"
        }  ,

        {
            "controlID": "30",
            "command": "DoAction"
            },
            {
                "controlID": "51",
            "command": "DoAction"
            }
            
            
        ],
        "formOID": "W5543POAC"
    },
         "stackId":';

         $request6=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

       $requestdata=$request1.$request2.$request3.$request4.$request5.$request6;

        $curl = curl_init();

          curl_setopt_array($curl, array(
          CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS =>$requestdata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
          ),
        ));

         $result = curl_exec($curl);

         curl_close($curl);
        //echo $response;
         $response=json_decode($result,true);
         session()->put('stackId',$response['stackId']);
         session()->put('stateId',$response['stateId']);
         session()->put('rid',$response['rid']);
         //return $response;
        }

        public function closeApprove_rejectForm()
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "controlID": "13",
                 "command": "DoAction"
              }
                
            ],
            "formOID": "W5543POAA"
             },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
              $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);

        }

        public function getAwaitingApprovalOrderDetails($request)
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "command": "SetQBEValue",
                 "controlID": "1[34]",
                   "value": "';
            $request4= $request;
            $request5='"
            }  ,

            {
                "controlID": "30",
                "command": "DoAction"
                },
                {
                    "controlID": "54",
                "command": "DoAction"
                }
                
                
            ],
            "formOID": "W5543POAC"
        },
             "stackId":';

             $request6=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

           $requestdata=$request1.$request2.$request3.$request4.$request5.$request6;


            $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

             $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);
             //$data= $response['fs_P5543POA_W5543POAF']['data']['gridData']['rowset'];
             return $response;
        }
        public function closeAwaitingorderDetailForm()
        {
            $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
                "controlID": "13",
                 "command": "DoAction"
              }
                
            ],
            "formOID": "W5543POAF"
             },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$request4;
              $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);

        }
        public function setRejectionReasonAndRejectOrder($request)
        {
             $request1='{
            "token": "';
            $request2=session()->get('token');
            $request3='","deviceName": "Postman",
           
            "aliasNaming": true,    
            "allowCache": true,
            "maxPageSize": "100",
            "action": "execute",
            "outputType": "VERSION2",
            "actionRequest": {
            
            "formActions": [
            
               {
            "controlID": "65",
            "value": "';
            $reason=$request['reason'].'",
            "command": "SetControlValue"
            },
             {
            "controlID": "';
            $controlId=$request['controlId'].'",
            "command": "DoAction"
            }
                
            ],
            "formOID": "W5543POAA"
             },
             "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

          $requestdata=$request1.$request2.$request3.$reason.$controlId.$request4;
              $curl = curl_init();

              curl_setopt_array($curl, array(
              CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS =>$requestdata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
              ),
            ));

            $result = curl_exec($curl);

             curl_close($curl);
            //echo $response;
             $response=json_decode($result,true);
             session()->put('stackId',$response['stackId']);
             session()->put('stateId',$response['stateId']);
             session()->put('rid',$response['rid']);

        }

        public function  openNonAwaitingForm(Request $request)
        {
            $request1='{
        "token": "';
        $request2=session()->get('token');
        $request3='","deviceName": "Postman",
       
        "aliasNaming": true,    
        "allowCache": true,
        "maxPageSize": "100",
        "action": "execute",
        "outputType": "VERSION2",
        "actionRequest": {
        
        "formActions": [
        
           {
            "command": "SetQBEValue",
             "controlID": "1[34]",
               "value": "';
        $request4= $request['value'];
        $request5='"
        }  ,

        {
            "controlID": "30",
            "command": "DoAction"
            },
            {
                "controlID": "58",
            "command": "DoAction"
            }
            
            
        ],
        "formOID": "W5543POAC"
    },
         "stackId":';

         $request6=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

       $requestdata=$request1.$request2.$request3.$request4.$request5.$request6;
       return $requestdata;
        $curl = curl_init();

          curl_setopt_array($curl, array(
          CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS =>$requestdata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
          ),
        ));

         $result = curl_exec($curl);

         curl_close($curl);
        //echo $response;
         $response=json_decode($result,true);
         session()->put('stackId',$response['stackId']);
         session()->put('stateId',$response['stateId']);
         session()->put('rid',$response['rid']);
         return $response;
          $data= $response['fs_P5543POA_W5543POAD']['data']['gridData']['rowset'];
          return $data;
        }

        public function  closeNonAwaitingForm()
        {
            $request1='{
        "token": "';
        $request2=session()->get('token');
        $request3='","deviceName": "Postman",
       
        "aliasNaming": true,    
        "allowCache": true,
        "maxPageSize": "100",
        "action": "execute",
        "outputType": "VERSION2",
        "actionRequest": {
        
        "formActions": [
        
           
            {
            "controlID": "13",
            "command": "DoAction"
            }
            
            
        ],
        "formOID": "W5543POAD"
    },
         "stackId":';

         $request4=session()->get('stackId').',"stateId":'.session()->get('stateId').', "rid": "'.session()->get('rid').'"}';

       $requestdata=$request1.$request2.$request3.$request4;

        $curl = curl_init();

          curl_setopt_array($curl, array(
          CURLOPT_URL => "http://jdedv92.am.edwards.lcl:8540/jderest/appstack",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS =>$requestdata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
          ),
        ));

         $result = curl_exec($curl);

         curl_close($curl);
        //echo $response;
         $response=json_decode($result,true);
         session()->put('stackId',$response['stackId']);
         session()->put('stateId',$response['stateId']);
         session()->put('rid',$response['rid']);
         //return $response;
        }
}
