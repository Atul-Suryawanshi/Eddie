$(document).foundation();

$('.ajax-popup-link').magnificPopup({
	type: 'ajax',
	closeBtnInside:true
	
});

$('.img-popup').magnificPopup({
	type: 'image',
	removalDelay: 300,
	mainClass: 'mfp-with-fade',
	closeOnContentClick: true
});

$(".arrow-holder").click(function () {
	$(this).parent().parent().parent().parent().find('[class^=action-box2]').slideToggle("slow");
	$(this).find(".reveal1").toggleClass("icon-top-arrow icon-down-arrow");

});

$(".apath").click(function () {

	$(this).find(".dd1").slideToggle("fast");
	$(this).find(".reveal2").toggleClass("icon-top-arrow icon-down-arrow");

});

$(".apath2").click(function () {
	//alert('test');

	//$(".dd2").slideToggle("fast");
	$(this).parent().find('[class^=dd2]').slideToggle("fast");
	

});

